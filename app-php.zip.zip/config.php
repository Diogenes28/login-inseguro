<?php
// config.php — armazena as credenciais de forma separada
$host = "localhost";
$db   = "sistema_login";
$user = "root";
$pass = "root"; // Senha padrão do MAMP
//$pass = getenv('DB_PASSWORD');